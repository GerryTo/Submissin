package com.dicoding.submission2.iu.main

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.submission2.R

class SplashScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        supportActionBar?.hide()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val imgSymbol: ImageView = findViewById(R.id.img_symbol)
        imgSymbol.alpha = 0f

        imgSymbol.animate().setDuration(1500).alpha(1f).withEndAction{
            val splashScreen = Intent(this, MainActivity::class.java)
            startActivity(splashScreen)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

    }
}