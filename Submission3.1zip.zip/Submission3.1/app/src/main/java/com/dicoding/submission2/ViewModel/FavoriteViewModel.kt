package com.dicoding.submission2.ViewModel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.submission2.UserResponseItem
import com.dicoding.submission2.database.FavoriteRepository

class FavoriteViewModel(application: Application):ViewModel() {

    private val mFavoriteRepository: FavoriteRepository = FavoriteRepository(application)

    fun getAllFavorite():LiveData<List<UserResponseItem>> = mFavoriteRepository.getAllFavorite()

    fun delete(id:Int?){
        if (id != null) {
            mFavoriteRepository.delete(id)
        }
    }
}