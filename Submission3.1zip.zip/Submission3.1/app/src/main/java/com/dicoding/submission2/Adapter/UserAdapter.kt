package com.dicoding.submission2.Adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.submission2.DetailUser
import com.dicoding.submission2.R
import com.dicoding.submission2.UserResponseItem

class UserAdapter(private val listData : ArrayList<UserResponseItem>):RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        val tvUsername:TextView = itemView.findViewById(R.id.tv_username)
        val imgProfile: ImageView = itemView.findViewById(R.id.img_photo)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.list_data, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvUsername.text = listData[position].login
        Glide.with(holder.itemView.context)
            .load(listData[position].avatarUrl)
            .into(holder.imgProfile)
        holder.itemView.setOnClickListener { v->
            val intentData = Intent(v.context, DetailUser::class.java)
            intentData.putExtra(DetailUser.EXTRA_USER, listData[position].login)
            v.context.startActivity(intentData)
        }
    }

    override fun getItemCount()=listData.size
}