package com.dicoding.submission2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class SplashScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        supportActionBar?.hide()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        var imgSymbol: ImageView = findViewById(R.id.img_symbol)
        imgSymbol.alpha = 0f

        imgSymbol.animate().setDuration(1500).alpha(1f).withEndAction{
            val splashScreen = Intent(this, MainActivity::class.java)
            startActivity(splashScreen)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }

    }
}