package com.dicoding.submission2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.submission2.Adapter.UserAdapter
import com.dicoding.submission2.ViewModel.FavoriteViewModel
import com.dicoding.submission2.ViewModel.FragmentViewModel
import com.dicoding.submission2.databinding.ActivityDetailUserBinding
import com.dicoding.submission2.databinding.ActivityFavoriteBinding

class FavoriteActivity : AppCompatActivity() {

    private lateinit var favoriteViewModel: FavoriteViewModel
    private lateinit var binding: ActivityFavoriteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        favoriteViewModel = obtainViewModel(this@FavoriteActivity)

        favoriteViewModel.getAllFavorite().observe(this, { FavoriteList ->
            if(FavoriteList != null){
                
            }
        })

    }

    private fun obtainViewModel(activity: AppCompatActivity): FavoriteViewModel{
        val factory = ViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory).get(FavoriteViewModel::class.java)
    }

    private fun showListUser(user: ArrayList<UserResponseItem>?) {
        val adapter = user?.let { UserAdapter(it) }
        binding.rvUser.adapter= adapter
    }
}